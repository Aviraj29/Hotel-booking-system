// import logo from './logo.svg';
// import './App.css';
// import About from './components/about/About';
// import Comment1 from './components/faq/Comment1';
// import Comment from './components/faq/Comments';
// import Qfinal from './components/faq/Qfinal';
// import Rating from './components/faq/Rating'; 
// import LogIn from './components/login/LogIn';
// import About from './components/about/About';
// import Promotions from './components/Promotions';
// import Reservation from './components/Reservation';
// import SelectedRoomPage from './components/rooms-page/SelectedRoomPage';
// import RoomsFilter from './components/rooms-page/RoomsFilter';
// import Gallery from './components/gallery/Gallery';
// import FromsR from './components/form/FromsR';
// import Bookingcard from './components/booking-card/Bookingcard';
// import Header from './components/header/Header';
// import Navbar from './components/navbar/Navbar'
// import Rooms from './components/room-card/Rooms';
import HotelRouter from './HotelRouter';
// import PaymentForm from './components/payment/PaymentForm';
// import Footer from './components/footer/Footer';
// import HotelBookingPage from './components/review/HotelBookingPage';
// import ContactForm from './components/contact_form/ContactForm';
// import Icon from './components/services/Icon';
// import EventForm from './components/event/EventForm';
// import SpecialEvent from './components/event/SpecialEvent';

function App() {
  return (
    <>
    <HotelRouter/>     

    {/* <Header/> */}  
    {/* <Navbar/> */} 
    {/* <Bookingcard/> */}
    {/* <Rooms/> */}
    {/* <RoomsFilter/> */}
    {/* <FromsR/> */}
    {/* <Reservation/> */}
    {/* <Promotions/> */} 
    {/* <Gallery/> */}
    {/* <About/> */}
    {/* <LogIn/> */}
    {/* <Qfinal/> */}
    {/* <Rating/> */}
    {/* <EventForm/> */}
    {/* <SpecialEvent/> */}
    {/* <ContactForm/> */}
    {/* <HotelBookingPage/> */}
    {/* <Footer/> */}
    {/* <About/> */}
    {/* <PaymentForm/> */}
    
  


    </>
  );
}

export default App;
 