
const GalleryData = [
    {
        img: '/images/gallery/img36.jpg',
        title: "gallery One"
    },
    {
        img: '/images/gallery/img15.jpg',
        title: "gallery One"
    },
    {
        img: '/images/gallery/img16.jpg',
        title: "gallery One"
    },
    {
        img: '/images/gallery/img17.jpg',
        title: "gallery One"
    },
    {
        img: '/images/gallery/img18.jpg',
        title: "gallery One"
    },
    {
        img: '/images/gallery/img22.jpg',
        title: "gallery One"
    }
];

export default GalleryData