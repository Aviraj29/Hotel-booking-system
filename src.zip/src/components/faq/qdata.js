 const qdata=[
    {
    id:1,
    question:"What Are The Different Types Of Rooms Exist In A Hotel?",
    answer:"Single Room,Double Room / Twin Room,Triple Room,Dormitory,Cabana,Studio,Suits.Single suits, Double suits, Duplex suit, Royal Suit, Pent house"
    },
    { 
        id:2,
        question:"What Is The Difference Between Check In And Check Out?",
        answer:" Action of arriving and registering in a hotel is called check in. There are various formalities, which are involved with check in procedures "
    },
    {
        id:3,
        question:" What Do You Understand By Accommodation?",
        answer :"Accommodation can be defined as a place to stay overnight. There are two types of accommodations namely serviced and non serviced. Some of them are directly related to tourism and some of them are not directly related to tourism but they provide overnight stay facility for the travelers. "
        
    },
    {
    id:4,
    question:"What Do You Understand By Catering?",
    answer :"Catering refers to food and drinks whereas catering industry refers to hospitality industry that provides foods, drinks and in certain section accommodation also"
    
    },
    {
        id:5,
        question:"What Is The Difference Between Check In And Check Out?",
        answer :"Action of arriving and registering in a hotel is called check in. There are various formalities, which are involved with check in procedures"
      
    },
    {
        id:6,
        question:"What Are The Various Sectors In The Hotel Industry? Why Are They Important?",
        answer:"Knowing your text books well always helps, especially when you are faced with questions like these."
    }
    ];
export default qdata;