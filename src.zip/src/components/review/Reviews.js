import React from 'react';
import CustomerReview from './CustomerReview';
               
const Reviews = () => {
                  
  return (
    <div> 

     <h1 className='review-h1'>Grand Hotel</h1>   
    <CustomerReview />
                   
    </div>  
  );
};
 
export default Reviews;


























// import React from 'react';
// import CustomerReview from './CustomerReview';

// const Reviews = () => {
//   // Other hotel booking related content and components
//   return (
//     <div>
//       {/* Display hotel booking information */}
//       <h2>Hotel Booking Page</h2>
//       {/* Display other booking details */}
//       {/* ... */}

//       {/* Use the CustomerReview component */}
//       <CustomerReview />

//       {/* Add other booking-related elements */}
//       {/* ... */}
//     </div>
//   );
// };

// export default Reviews;






