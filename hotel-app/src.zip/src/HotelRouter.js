import React from 'react'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Navbar from './components/navbar/Navbar'
import RoomsFilter from './components/rooms-page/RoomsFilter'

// import Rooms from './components/room-card/Rooms'
// import Header from './components/header/Header'
import Home from './components/Home'
import SelectedRoomPage from './components/rooms-page/SelectedRoomPage'
import Promotions from './components/Promotions'
import Reservation from './components/Reservation'
import OfferRoomPage from './components/rooms-page/OfferRoomPage'
import Header from './components/header/Header'



export default function HotelRouter() {
  return (
    <>
    <BrowserRouter>
    <Routes>
        <Route path='/' element={<OnlyHeader/>}/>

        <Route path='/' element={<Navbar/>}>    
        <Route path='/res' element={<Reservation/>}/>
        {/* <Route path="/selected-room" element={<SelectedRoomPage/>} /> */}
        <Route path='/rooms' element={<RoomsFilter/>}/>
        <Route path="/rooms/selected-room" element={<SelectedRoomPage/>} />
        <Route path='/offer' element={<Promotions/>}/>
        <Route path="/offer/selected-room" element={<OfferRoomPage/>} />
        
      </Route>
    </Routes>
    </BrowserRouter>
    </>
  ) 
}
function OnlyHeader() {
  return (
    <>
      <Header />
      {/* <Navbar /> */}
      <Routes>
        <Route index element={<Home />} />
        
      </Routes>
    </>
  );
}
