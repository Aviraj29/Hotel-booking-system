// import logo from './logo.svg';

import './App.css';
// import Promotions from './components/Promotions';
// import Reservation from './components/Reservation';
// import SelectedRoomPage from './components/rooms-page/SelectedRoomPage';
// import RoomsFilter from './components/rooms-page/RoomsFilter';
import HotelRouter from './HotelRouter';
// import FromsR from './components/form/FromsR';
// import Bookingcard from './components/booking-card/Bookingcard';
// import Header from './components/header/Header';
// import Navbar from './components/navbar/Navbar'
// import Rooms from './components/room-card/Rooms';


function App() {
  return (
    <>
    {/* <Header/> */}
    {/* <Navbar/> */}
    {/* <Bookingcard/> */}
    {/* <Rooms/> */}
    {/* <RoomsFilter/> */}
    <HotelRouter/>
    {/* <FromsR/> */}
    {/* <Reservation/> */}
    {/* <Promotions/> */}

    </>
  );
}

export default App;
 