import React from 'react'

export default function RoomCard(props) {
  return (
    <div className="room-card">
      <div className="room-details">
        <img className="room-image" src={props.image} alt="" />
        <h2 className='room-name'>{props.name}</h2>
        <h3 className='room-price'>Price: {props.price}</h3>
        <p className='room-desc'>{props.descpriction}</p>
        <button className='room-button btn btn-light'>Book</button>
      </div>
    </div>
  );
}
