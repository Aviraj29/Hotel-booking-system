
export default function HeaderItems(props) {
  return <li> <i className={props.icon}></i>{props.headerName}</li>
  
}
